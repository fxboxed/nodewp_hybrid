/* global customJsonpCallback */

"use strict";

customJsonpCallback( { answer: 42 } );
