"use strict";

const $ = require( "jquery-migrate" );

module.exports.$required = $;
